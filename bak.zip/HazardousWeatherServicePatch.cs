﻿using HarmonyLib;
using Timberborn.HazardousWeatherSystem;
using UnityEngine;

namespace Timberborn_FloodSeason
{ 
    // prevent seasons to trigger
    [HarmonyPatch(typeof(HazardousWeatherService))]
    [HarmonyPatch("StartHazardousWeather")]
    class HazardousWeatherServiceStartHazardousWeatherPatch
    {
        static bool Prefix()
        {
            return false;
        }
    }
    [HarmonyPatch(typeof(HazardousWeatherService))]
    [HarmonyPatch("StartHazardousWeather")]
    class HazardousWeatherServiceStopHazardousWeatherPatch
    {
        static bool Prefix()
        {
            return false;
        }
    }
}
