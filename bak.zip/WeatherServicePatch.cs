﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using System.Text;
using Timberborn.WeatherSystem;
using UnityEngine;
namespace Timberborn_FloodSeason
{
    [HarmonyPatch(typeof(WeatherService))]
    [HarmonyPatch("StartNextDay")]
    class WeatherServicePatch
    {
        static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions) // disable seasons
        {
            var codes = new List<CodeInstruction>(instructions);
            // search first builder call
            int return_index = 0;
            int call_count = 0;
            for (; return_index < codes.Count; return_index++)
            {
                CodeInstruction code = codes[return_index];
                if (code.opcode == OpCodes.Call)
                {
                    call_count++;
                }
                if (call_count == 2)
                {
                    break;
                }
            }
            // exit after incrementing day
            codes[return_index+1] = new CodeInstruction(OpCodes.Ret);
            return codes;
        }
    }
}
